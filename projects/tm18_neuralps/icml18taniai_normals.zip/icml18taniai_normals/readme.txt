We provide data of estimated normals for DiLiGenT dataset (https://sites.google.com/site/photometricstereodata/).
The file format is the same with DiLiGenT dataset. For visualization, please refer to visualize.py.
If you use this data in your paper, please cite our ICML2018 paper below.

@inproceedings{Taniai18,
  author    = {Tatsunori Taniai and
               Maehara Takanori},
  title     = {{Neural Inverse Rendering for General Reflectance Photometric Stereo}},
  booktitle = {{Proceedings of the 35th International Conference on Machine Learning (ICML)}},
  year      = {2018},
}