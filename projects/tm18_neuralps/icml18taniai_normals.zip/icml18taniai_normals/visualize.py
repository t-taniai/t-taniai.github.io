
from PIL import Image
import scipy.io as sio
import numpy as np

def load_normals(file):
    N = sio.loadmat(file)
    key = list(N.keys())[-1]
    N = np.array(N[key]).astype(np.float32)
    return N

def vis_normals(N):
    N = N + np.array([1, 1, 1], N.dtype)[None, None]
    return N * (255.0/2.0)


file = 'ballPNG_Normal_ICML18Taniai'
N = load_normals(file + '.mat')
I = Image.fromarray(vis_normals(N).astype(np.uint8))
I.save(file + '.png')

